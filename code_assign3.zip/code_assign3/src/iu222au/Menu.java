package iu222au;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.awt.event.ItemEvent;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTable;

public class Menu extends JPanel {

	private static final long serialVersionUID = 1L;
	private JComboBox difficulty;
	public static int level;
	public static JLabel userName;
	public int[] scores;
	public String[] scores_user;
	private int count;
	private JTable table;
	private DefaultTableModel model;

	public int getLevel() {
		return level;
	}
	
	
	public void selectionSort(int[] a,String[] b) {
	    int n = a.length;
	    for(int i=0; i< n; i++) {
	        int max = i;
	        for(int j=i+1; j<n; j++) {
	            if(a[j] > a[max]) {
	                max = j;
	            }
	        }
	        int tmp1=a[i];
	        a[i]=a[max];
	        a[max]=tmp1;
	        String tmp2=b[i];
	        b[i]=b[max];
	        b[max]=tmp2;
	    }
	}
	

	public Menu() {
		setBounds(0,0,700,550);
		setBorder(new EmptyBorder(100, 100, 700, 550));
		setLayout(null);
		
		scores_user=new String[2500];
		scores=new int[2500];
		JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(152, 160, 308, 263);
        add(scrollPane);
        model = new DefaultTableModel();
        table = new JTable(model);
        scrollPane.setViewportView(table);
	    model.addColumn("No");
	    model.addColumn("Id");
	    model.addColumn("Scores");
        
	    	try {
				count = 0;
				Scanner sc=new Scanner(new File("Scores.txt"));
				while(sc.hasNext()) {
					scores_user[count]=sc.next();
					scores[count++]=Integer.parseInt(sc.next());
				}
				sc.close();
				selectionSort(scores,scores_user);
				for(int i=0;i<15&& i<count;i++) {
					model.addRow(new Object[] { new Integer(i+1),scores_user[i],new Integer(scores[i]) });
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
			
		JButton playGame = new JButton("Play Game");
		playGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.lpane.removeAll();
				Hangman hangman = null;
				try {
					hangman = new Hangman();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				Main.lpane.add(hangman,new Integer(0),0);
			}
		});
		playGame.setBounds(21, 115, 119, 25);
		add(playGame);
		
		JButton viewScore = new JButton("High Scores");
		viewScore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				scores_user=new String[2500];
				scores=new int[2500];
				if(viewScore.getText()=="My Scores") {
					try {
						count = 0;
						Scanner sc=new Scanner(new File("Scores.txt"));
						while(sc.hasNext()) {
							scores_user[count]=sc.next();
							scores[count++]=Integer.parseInt(sc.next());
						}
						sc.close();
						selectionSort(scores,scores_user);
						model = new DefaultTableModel();
						table.setModel(model);
						model.addColumn("No");
					    model.addColumn("Id");
					    model.addColumn("Scores");
						for(int i=0;i<15&& i<count;i++)
							model.addRow(new Object[] { new Integer(i+1),scores_user[i],new Integer(scores[i]) });
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
					viewScore.setText("High Scores");
				}else {
					try {
						count = 0;
						Scanner sc=new Scanner(new File("Scores.txt"));
						while(sc.hasNext()) {
							String tmp1=sc.next();
							String tmp2=sc.next();
							if(Main.userid.equals(tmp1)) {
								scores_user[count]=tmp1;
								scores[count++]=Integer.parseInt(tmp2);
							}
						}
						sc.close();
						selectionSort(scores,scores_user);
						model = new DefaultTableModel();
						table.setModel(model);
						model.addColumn("No");
					    model.addColumn("Id");
					    model.addColumn("Scores");
						for(int i=0;i<count;i++)
							model.addRow(new Object[] { new Integer(i+1),scores_user[i],new Integer(scores[i]) });
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
					viewScore.setText("My Scores");
				}
			}
		});
		viewScore.setToolTipText("");
		viewScore.setBounds(21, 153, 119, 30);
		add(viewScore);
		
		JButton quitGame = new JButton("Exit");
		quitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.frame.dispose();
			}
		});
		quitGame.setBounds(21, 395, 119, 25);
		add(quitGame);
		
		String[] difficulties=new String[] {"Easy","Medium","Hard"};
		difficulty = new JComboBox(difficulties);
		difficulty.setSelectedIndex(level);
		difficulty.setBackground(Color.WHITE);
		difficulty.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				level=difficulty.getSelectedIndex();
			}
		});
		
		level=0;
		difficulty.setBounds(152, 116, 97, 22);
		add(difficulty);
		
		userName = new JLabel("");
		userName.setFont(new Font("Sylfaen", Font.PLAIN, 20));
		userName.setBounds(21, 49, 323, 25);
		add(userName);
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 700, 550);
		label.setIcon(new ImageIcon("menu_background.JPG"));
		add(label);
		
	}
}