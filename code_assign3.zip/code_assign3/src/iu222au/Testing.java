package iu222au;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Random;

import org.junit.Before;

import org.junit.Test;
//import static org.junit.Assert.*;
//import static org.junit.Test

public class Testing {
	
	Hangman hm;
	Menu menu;
	Login login;
	
	@Before
	public void setUp() throws IOException{
		 hm = new Hangman();
		 menu = new Menu();
		 login = new Login();
	}
	
	


	@Test
	public void testIsExist() {
		
		boolean expected = true;
		boolean actual = login.isExist("iu222au");
		
		assertEquals(expected,actual);
		
	}
	
	
	@Test
	public void testForIsContains() throws IOException {
		
		boolean expected=true;
		boolean actual = hm.isContains('e','E',"Egemen");
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void testForIsContainsNumber() throws IOException {
		
		boolean expected=false;
		boolean actual = hm.isContains('1','3',"Egemen");
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void testSortForEmptyAndSingleton() {
				
		int[] a1 = {};
		String[] b1 = {};
		int[] arr1 = new int[0];           //Empty array
		menu.selectionSort(a1,b1);
		assertEquals(0,a1.length);
		
		int[] a2 = {160};                  //Singleton array
		String[] b2 = {"iu222au"};
		menu.selectionSort(a2, b2);
		assertEquals(1,a2.length);
		assertEquals(160,a2[0]);
		assertEquals("iu222au",b2[0]);
		
	}
	
	@Test
	public void testSortFortEqualAndRandom(){
		
		int[] a3 = {160,160,160};                   //All elements are equal
		String[] b3 = {"iu222au","ipek","berk"};
		menu.selectionSort(a3, b3);
		assertEquals(3,a3.length);
		for(int i : a3)
			assertEquals(160,i);
		
		int[] a4 = random(10,10);               //Random array of size 10
		String[] b4 = {"a","b","c","d","e","f","g","h","i","j"};
		menu.selectionSort(a4, b4);
		for(int i=0; i<a4.length-1; i++)
			assertTrue(a4[i]>=a4[i+1]);
		
		
	}

	/*
	 * Generates random integer array of length size with elements
	 * in the range [0,max].
	 */
	
	private int[] random(int size,int max) {
		/* Setup random generator */
		Random rand = new Random();
		
		/* Add random numbers in range [1,max] */
		int[] arr = new int[size];
		for (int i=0;i<size;i++) {
			//int n = rand.nextInt() % max;
			int n = rand.nextInt(max);
			arr[i] = n;
		}
		return arr; 
	}	
	
	
}

