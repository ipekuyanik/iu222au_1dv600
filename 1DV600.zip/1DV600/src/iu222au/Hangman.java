package iu222au;

//175

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;
import javax.swing.Timer;

public class Hangman extends JPanel {				//250		400

		private static final long serialVersionUID = 1L;
		private int error=8,count=0,lenght,counter;
		private String selected;
		private String[] words =new String[1000];
		private JButton btnA = new JButton("A");
		private JButton btnB = new JButton("B");
		private JButton btnC = new JButton("C");
		private JButton btnD = new JButton("D");
		private JButton btnE = new JButton("E");
		private JButton btnF = new JButton("F");
		private JButton btnG = new JButton("G");
		private JButton btnH = new JButton("H");
		private JButton btnI = new JButton("I");
		private JButton btnJ = new JButton("J");
		private JButton btnK = new JButton("K");
		private JButton btnL = new JButton("L");
		private JButton btnM = new JButton("M");
		private JButton btnN = new JButton("N");
		private JButton btnO = new JButton("O");
		private JButton btnP = new JButton("P");
		private JButton btnQ = new JButton("Q");
		private JButton btnR = new JButton("R");
		private JButton btnS = new JButton("S");
		private JButton btnT = new JButton("T");
		private JButton btnU = new JButton("U");
		private JButton btnV = new JButton("V");
		private JButton btnW = new JButton("W");
		private JButton btnX = new JButton("X");
		private JButton btnY = new JButton("Y");
		private JButton btnZ = new JButton("Z");
		private JLabel[] label = new JLabel[10];
		private JLabel[] lblLetter = new JLabel[10];
		private JLabel label_Error ,labelResult,hangmanLabel,label_score,lbl_Last;
		private JButton newGame,quitGame,next;
		private BufferedImage[] img;
		private JLabel photo;
		private final JPanel panel = new JPanel();
		private int score=0;
		private JLabel label_timer;
		private Timer watch;
		
		public void startTimer(int countPassed) {
			ActionListener action=new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(counter==0) {
						label_timer.setText("Time: 0");
						watch.stop();
						labelResult.setText("Game Over");
						labelResult.setVisible(true);
						newGame.setVisible(true);
						buttonEnable(false);
						for(int i=0;i<selected.length();i++) {
							lblLetter[i+((10-selected.length())/2)].setVisible(true);
							lblLetter[i+((10-selected.length())/2)].setText(""+ Character.toUpperCase(selected.charAt(i)));
						}
					}else {
						label_timer.setText("Time :"+counter);
						counter--;
					}
				}
			};
			watch=new Timer(1000,action);
			watch.setInitialDelay(0);
			watch.start();
			counter=countPassed;
		}
		
		public void buttonEnable(boolean tmp) {
			btnA.setEnabled(tmp);btnB.setEnabled(tmp);btnC.setEnabled(tmp);btnD.setEnabled(tmp);btnE.setEnabled(tmp);btnF.setEnabled(tmp);
			btnG.setEnabled(tmp);btnH.setEnabled(tmp);btnI.setEnabled(tmp);btnJ.setEnabled(tmp);btnK.setEnabled(tmp);btnL.setEnabled(tmp);
			btnM.setEnabled(tmp);btnN.setEnabled(tmp);btnO.setEnabled(tmp);btnP.setEnabled(tmp);btnQ.setEnabled(tmp);btnR.setEnabled(tmp);
			btnS.setEnabled(tmp);btnT.setEnabled(tmp);btnU.setEnabled(tmp);btnV.setEnabled(tmp);btnW.setEnabled(tmp);btnX.setEnabled(tmp);
			btnY.setEnabled(tmp);btnZ.setEnabled(tmp);
		}
			
		public void addScore() {
			try {
	        	    FileWriter printer = new FileWriter(new File("Scores.txt"),true);
		        	printer.write(Main.userid+" "+score+" ");
					printer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		public boolean isContains(char char1, char char2,String selected) {
			if(selected.contains(""+char1) || selected.contains(""+char2))
				return true;
			else 
				return false;
		}
			
		public void pressedButton(JButton tmp, char char1, char char2,String selected) {	//Pressed Letters Button
			tmp.setEnabled(false);
			if(isContains(char1, char2, selected)) {				//Checking any letter same your input
				for(int i=0;i<selected.length();i++) {
					if(selected.charAt(i)==char1|| selected.charAt(i)==char2) {				//If any letter is true, show the letter in area
						lblLetter[i+((10-selected.length())/2)].setVisible(true);		
						lblLetter[i+((10-selected.length())/2)].setText(""+char2);
						count++;
						if(Menu.level==2)													//Calculating scores
							score+=error*20;
						else if(Menu.level==1)
							score+=error*15;
						else
							score+=error*10;
						label_score.setText("Score: "+score);
					}
				}
				if(count==selected.length()) {												//Checking are you filled all letters area?
					labelResult.setText("You win");
					labelResult.setVisible(true);
					next.setVisible(true);
					buttonEnable(false);
				}
			}else {																			//Checking is game finished because of errors
				error=error-1;
				label_Error.setText(""+error);
				photo.setIcon(new ImageIcon(img[error]));
				if(error==0) {
					watch.stop();
					label_timer.setText("Time: 0");
					labelResult.setText("Game Over");
					labelResult.setVisible(true);
					newGame.setVisible(true);
					buttonEnable(false);
					for(int i=0;i<selected.length();i++) {
						lblLetter[i+((10-selected.length())/2)].setVisible(true);
						lblLetter[i+((10-selected.length())/2)].setText(""+ Character.toUpperCase(selected.charAt(i)));
					}
					addScore();
				}
			}
		}
		
		
		public void createrLabels(JLabel[] tmp,String text,boolean cont, int size,int x,int y, int weight, int height) { //Input Letters area creating
			for(int i=0; i<10;i++) {
				tmp[i] = new JLabel(text);
				tmp[i].setFont(new Font("Tahoma", Font.BOLD, size));
				tmp[i].setBounds(x, y, weight, height);
				x=x+52;
				tmp[i].setVisible(cont);
				add(tmp[i]);
			}
		}
		public void createrButton(JButton tmp,int x,int y) {											//Letters button creater
			tmp.setBorder(null);
			tmp.setOpaque(false);
			tmp.setFont(new Font("Tahoma", Font.BOLD, 15));
			tmp.setBounds(x, y, 47, 47);
			add(tmp);
		}
		
		
		public String selectedWord() {																	//Random word finder
			//Random rnd=new Random();
			//return words[rnd.nextInt(lenght)];
			return words[81];
		}

		
		public Hangman() throws IOException {

			setBackground(new Color(176, 224, 230));
			setBounds(0,0,700,550);
			setBorder(new EmptyBorder(100, 100, 700, 550));
			setLayout(null);
			setBackground(new Color(176, 224, 230));
			panel.setBounds(0, 0, 700, 270);
			panel.setLayout(null);
			panel.setBackground(Color.WHITE);
			add(panel);
			BufferedReader reader = null;
			int i;
			String line;
			FileReader file;	
			
			img=new BufferedImage[9];																//Adding photo of hangman
			img[0]=ImageIO.read(new FileInputStream("(0).JPG"));
			img[1]=ImageIO.read(new FileInputStream("(1).JPG"));
			img[2]=ImageIO.read(new FileInputStream("(2).JPG"));
			img[3]=ImageIO.read(new FileInputStream("(3).JPG"));
			img[4]=ImageIO.read(new FileInputStream("(4).JPG"));
			img[5]=ImageIO.read(new FileInputStream("(5).JPG"));
			img[6]=ImageIO.read(new FileInputStream("(6).JPG"));
			img[7]=ImageIO.read(new FileInputStream("(7).JPG"));
			img[8]=ImageIO.read(new FileInputStream("(8).JPG"));

			i=0;
			if(Menu.level==2) {																		//Choosing number of letter according to your choice for difficulty
				file = new FileReader("4 Letters");
		        reader = new BufferedReader(file);
		        while ((line = reader.readLine()) !=null) 
		        	words[i++]=line;
			}else if(Menu.level==1) {
		        file = new FileReader("5 Letters");
		        reader = new BufferedReader(file);
		        while ((line = reader.readLine()) !=null) 
		        	words[i++]=line;
				file = new FileReader("6 Letters");
		        reader = new BufferedReader(file);
		        while ((line = reader.readLine()) !=null) 
		        	words[i++]=line;
			}else if(Menu.level==0) {
		        file = new FileReader("7 Letters");
		        reader = new BufferedReader(file);
		        while ((line = reader.readLine()) !=null) 
		        	words[i++]=line;
				file = new FileReader("8 Letters");
		        reader = new BufferedReader(file);
		        while ((line = reader.readLine()) !=null) 
		        	words[i++]=line;
			}
			lenght=i;
	        i=0;
	        
	        quitGame = new JButton("Back to Menu");													//Back to menu button
			quitGame.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Main.lpane.removeAll();
					Main.lpane.add(Main.menu,new Integer(0),0);
				}
			});
			quitGame.setBounds(544 ,36 , 120, 60);
			panel.add(quitGame);
	        
			label_Error=new JLabel("8");															//Shower total error
			label_Error.setFont(new Font("Tahoma", Font.PLAIN, 18));
			label_Error.setBounds(630, 204, 47, 16);
			panel.add(label_Error);
			
			labelResult=new JLabel();
			labelResult.setHorizontalAlignment(SwingConstants.CENTER);
			labelResult.setFont(new Font("Tahoma", Font.PLAIN, 18));
			labelResult.setBounds(544, 170, 120, 25);
			labelResult.setVisible(false);
			panel.add(labelResult);
			
			next=new JButton("Next");
			next.setBounds(544, 109, 120, 60);
			next.setVisible(false);
			panel.add(next);
			
			next.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					buttonEnable(true);
					next.setVisible(false);
					selected=selectedWord();
					int tmp=10-selected.length();
					tmp=tmp/2;
					for(int k=0;k<10;k++) {
						label[k].setVisible(false);
						lblLetter[k].setVisible(false);
					}
					for(int j=tmp;j<selected.length()+tmp;j++) 
						label[j].setVisible(true);
						labelResult.setVisible(false);
					count=0;
				}
			});
			
			newGame=new JButton("New Game");
			newGame.setBounds(544, 109, 120, 60);
			newGame.setVisible(false);
			panel.add(newGame);
			
			newGame.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					buttonEnable(true);
					newGame.setVisible(false);
					selected=selectedWord();
					int tmp=10-selected.length();
					tmp=tmp/2;
					for(int k=0;k<10;k++) {
						label[k].setVisible(false);
						lblLetter[k].setVisible(false);
					}
					for(int j=tmp;j<selected.length()+tmp;j++) 
						label[j].setVisible(true);
					labelResult.setVisible(false);
					error=8;
					count=0;
					score=0;
					photo.setIcon(new ImageIcon(img[error]));
					label_Error.setText(""+error);
					label_score.setText("Score: "+score);
					startTimer(100);
					//JOptionPane.showMessageDialog(null, selected, "Mesaj 1", 1);
				}
			});
			
			//////////////////////////////////////////////////////////////////////////////////////
			photo = new JLabel();
			photo.setBounds(180, 0, 300, 265);
			photo.setIcon(new ImageIcon(img[error]));
			panel.add(photo);
			
			hangmanLabel = new JLabel();
			hangmanLabel.setVerticalAlignment(SwingConstants.TOP);
			hangmanLabel.setHorizontalAlignment(SwingConstants.CENTER);
			hangmanLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
			hangmanLabel.setBounds(80, 0, 47, 250);
			hangmanLabel.setText("<html>H<BR>A<BR>N<BR>G<BR>M<BR>A<BR>N</html>");
			panel.add(hangmanLabel);
			
			lbl_Last = new JLabel("Left:");
			lbl_Last.setFont(new Font("Tahoma", Font.PLAIN, 18));
			lbl_Last.setBounds(571, 204, 47, 16);
			panel.add(lbl_Last);
			
			label_score = new JLabel("Score:");
			label_score.setFont(new Font("Tahoma", Font.PLAIN, 18));
			label_score.setBounds(571, 233, 106, 17);
			panel.add(label_score);
			
			label_timer = new JLabel("Time: ");
			label_timer.setFont(new Font("Tahoma", Font.PLAIN, 18));
			label_timer.setBounds(544, 7, 120, 16);
			panel.add(label_timer);
			
			createrLabels(label ,"_" ,false ,20 ,75 ,282 ,40 ,25 );
			createrLabels(lblLetter,"",false,25 ,86 ,278 ,26 , 20 );
			
			selected=selectedWord();
			int tmp=10-selected.length();
			tmp=tmp/2;
			for(i=tmp;i<selected.length()+tmp;i++) 
				label[i].setVisible(true);
			//JOptionPane.showMessageDialog(null, selected, "Mesaj 1", 1);
			
			
			///////////////////////////////////////////
			
			createrButton(btnA,50,320);
			btnA.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnA,'a','A',selected);
				}
			});
			
			createrButton(btnB,109,320);
			btnB.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnB,'b','B',selected);
				}
			});
			
			createrButton(btnC,168,320);
			btnC.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					pressedButton(btnC,'c','C',selected);
				}
			});
			
			createrButton(btnD,227,320);
			btnD.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnD,'d','D',selected);
				}
			});
			
			createrButton(btnE,286,320);
			btnE.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnE,'e','E',selected);
				}
			});
			
			createrButton(btnF,345,320);
			btnF.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnF,'f','F',selected);
				}
			});
			
			createrButton(btnG,404,320);
			btnG.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnG,'g','G',selected);
				}
			});
			
			createrButton(btnH,463,320);
			btnH.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnH,'h','H',selected);
				}
			});
			
			createrButton(btnI,522,320);
			btnI.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnI,'i','I',selected);
				}
			});

			createrButton(btnJ,581,320);
			btnJ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnJ,'j','J',selected);
				}
			});
			
			createrButton(btnK,75,380);
			btnK.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnK,'k','K',selected);
				}
			});
			
			createrButton(btnL,134,380);
			btnL.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnL,'l','L',selected);
				}
			});
			
			createrButton(btnM,193,380);
			btnM.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnM,'m','M',selected);
				}
			});
			
			createrButton(btnN,252,380);
			btnN.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnN,'n','N',selected);
				}
			});
			
			createrButton(btnO,311,380);
			btnO.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnO,'o','O',selected);
				}
			});
			
			createrButton(btnP,370,380);
			btnP.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnP,'p','P',selected);
				}
			});
			
			createrButton(btnQ,429,380);
			btnQ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnQ,'q','Q',selected);
				}
			});
			
			createrButton(btnR,488,380);
			btnR.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnR,'r','R',selected);
				}
			});
			
			createrButton(btnS,547,380);
			btnS.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnS,'s','S',selected);
				}
			});
			
			createrButton(btnT,131,440);
			btnT.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnT,'t','T',selected);
				}
			});
			
			createrButton(btnU,193,440);
			btnU.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnU,'u','U',selected);
				}
			});
			
			createrButton(btnV,252,440);
			btnV.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnV,'v','V',selected);
				}
			});

			createrButton(btnW,311,440);
			btnW.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnW,'w','W',selected);
				}
			});
			
			createrButton(btnX,370,440);
			btnX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnX,'x','X',selected);
				}
			});
			
			createrButton(btnY,429,440);
			btnY.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnY,'y','Y',selected);
				}
			});
			
			createrButton(btnZ,488,440);
			btnZ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					pressedButton(btnZ,'z','Z',selected);
				}
			});
			startTimer(100);
		}
	}