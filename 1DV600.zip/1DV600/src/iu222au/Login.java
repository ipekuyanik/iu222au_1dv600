package iu222au;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Rectangle;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Component;
import javax.swing.JPasswordField;

public class Login extends JPanel {

	private static final long serialVersionUID = 1L;
		private JTextField id;
		private JLabel labelInfo;
		private JButton login;
		private JButton register;
		private JButton guestUser;
		private JPasswordField password;
		private boolean chooser=true;
		private JLabel label;
		


		public Login() {
			setBounds(new Rectangle(0, 0, 700, 550));
			setAlignmentY(Component.TOP_ALIGNMENT);
			setAlignmentX(Component.LEFT_ALIGNMENT);
			setLayout(null);
			
			JLabel lblUserId = new JLabel("User Id:");                         //UserId Label
			lblUserId.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblUserId.setBounds(134, 216, 120, 25);
			add(lblUserId);
			
			JLabel lblPassword = new JLabel("Password:");						//Password Label
			lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblPassword.setBounds(134, 279, 120, 25);
			add(lblPassword);
			
			id = new JTextField();												//id TextField
			id.setBounds(277, 220, 223, 22);
			add(id);
			id.setColumns(10);
			
			password = new JPasswordField();									//password
			password.setEchoChar('*');
			password.setBounds(277, 283, 193, 22);
			add(password);
			
			JButton btnNewButton = new JButton("");								//Show password
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(chooser) {
						password.setEchoChar((char)0);			
						chooser=false;
					}else{
						password.setEchoChar('*');
						chooser=true;
					}
					
				}
			});
			btnNewButton.setBounds(482, 280, 18, 25);
			add(btnNewButton);
			
			
			login = new JButton("Login");										//Login button
			login.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						Scanner sc =new Scanner(new File("DataSet.txt"));
			        	while(sc.hasNext()) {
			        		String pass="";
							char[] tmp=password.getPassword();
							for(int i=0;i<tmp.length;i++)
								pass+=tmp[i];
							String tmp1=sc.next();
							String tmp2=sc.next();
							if(tmp1.equals(id.getText()))
								if(tmp2.equals(pass)) {
									Main.userid=tmp1;
									Main.password=tmp2;
									Menu.userName.setText("Welcome "+tmp1);
									Main.lpane.removeAll();
									Main.lpane.add(Main.menu,new Integer(0),0);
								}
			        	}
						labelInfo.setText("Wrong password or userId");
						sc.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	
				}
			});
			login.setBounds(403, 351, 97, 25);
			add(login);
			
			guestUser = new JButton("Guest User");								//Guest User Button
			guestUser.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Main.userid="guest";
					Menu.userName.setText("Welcome "+Main.userid);
					Main.lpane.removeAll();
					Main.lpane.add(Main.menu,new Integer(0),0);
				}
			});
			guestUser.setBounds(134, 351, 120, 25);
			add(guestUser);
			
			register = new JButton("Register");									//Register
			register.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					boolean control;
					control=isExist(id.getText());
			        	if(!control) {
			        		labelInfo.setText("This user already exist.");
			        	}else{
			        		char[] pas=password.getPassword();
			        		String pass="";
			        		for(int m=0;m<pas.length;m++)
				        		pass+=pas[m];
			        		if(id.getText().contains(" ") || pass.contains(" "))
			        			labelInfo.setText("Wrong character in password or username");
			        		else {
			        			labelInfo.setText("User created");
			        			FileWriter printer;
								try {
									printer = new FileWriter(new File("DataSet.txt"),true);
									printer.write("\n"+id.getText().toString()+" "+pass);
									printer.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
					        	
			        		}
			        	    
			        	}
					
				}
			});
			register.setBounds(277, 351, 97, 25);
			add(register);
			
			labelInfo = new JLabel();											//Secret Info
			labelInfo.setBounds(134, 301, 366, 16);
			add(labelInfo);
			
			label = new JLabel();
			label.setBounds(0, 0, 700, 550);
			label.setIcon(new ImageIcon("login_background.JPG"));
			add(label);
			
			
		}
		public boolean isExist(String id) {
			try {
	        	Scanner sc=new Scanner(new File("DataSet.txt"));
	        	while(sc.hasNext()) {
	        		if(sc.next().equals(id))
	        			return false;
	        		sc.next();
	        	}
	        	sc.close();
		    } catch (IOException e) {
		    	// TODO Auto-generated catch block
		    	e.printStackTrace();
		      }
			return true;
		}
	}